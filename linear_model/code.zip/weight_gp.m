clear all;close all;
A = importdata('Concrete_Data.xls');

dataset = A.data.Sheet1;
X_all = dataset(:,1:8);
X_all = X_all';
f_all = dataset(:,9);
X_all = projection(X_all,4);
d=size(X_all);
K = 10;
index = 1;
for i=1:K
   fold_indices(i)= index;
   index = index + d(2)/K;
end

sigma_noise_square = 0.03;
%iterate on all the folds
validation_index = 1;
validation_error=zeros(1,6);
for i=1:K 
    %fold for the validation
    if i ~= K
        a = fold_indices(validation_index);
        b = fold_indices(validation_index+1);
    else
        a = fold_indices(validation_index);
        b = d(2)+1;
    end
    n_ = b - a;
    X_ = X_all(:,a:b-1);
    f_ = f_all(a:b-1);
    
    n = d(2) - n_;
    X = X_all(:,1:a-1);
    X = [X,X_all(:,b:d(2))];
    f = f_all(1:a-1);
    f = [f;f_all(b:d(2))];
    
    weight_vector = layer_processing( X,f,sigma_noise_square );
    [ prediction, err ] = validation( X_,n_,f_,[],weight_vector,4,sigma_noise_square );
    validation_error(1)=validation_error(1)+err;
    %-------------------------------------------
    X2 = intermediate_output(X,weight_vector,n);
    X2 = projection(X2,4);
    weight_vector2 = layer_processing( X2,f,sigma_noise_square );
    W(:,1)=weight_vector2;
    [ prediction, err ] = validation( X_,n_,f_,weight_vector,W,4,sigma_noise_square );
    validation_error(2)=validation_error(2)+err;
    %--------------------------------------------
    X3 = intermediate_output(X2,weight_vector2,n);
    X3 = projection(X3,4);
    weight_vector3 = layer_processing( X3,f,sigma_noise_square );
    W(:,2)=weight_vector3;
    [prediction,err] = validation( X_,n_,f_,weight_vector,W,4,sigma_noise_square);
    validation_error(3)=validation_error(3)+err;
    %-------------------------------------------
    X4 = intermediate_output(X3,weight_vector3,n);
    X4 = projection(X4,4);
    weight_vector4 = layer_processing( X4,f,sigma_noise_square );
     W(:,3)=weight_vector4;
    [prediction,err] = validation( X_,n_,f_,weight_vector,W,4,sigma_noise_square);
    validation_error(4)=validation_error(4)+err;
    %-------------------------------------------
    X5 = intermediate_output(X4,weight_vector4,n);
    X5 = projection(X5,4);
    weight_vector5 = layer_processing( X5,f,sigma_noise_square );
    W(:,4)=weight_vector5;
    [prediction,err] = validation( X_,n_,f_,weight_vector,W,4,sigma_noise_square);
    validation_error(5)=validation_error(5)+err;
    %--------------------------------------------
    X6 = intermediate_output(X5,weight_vector5,n);
    X6 = projection(X6,4);
    weight_vector6 = layer_processing( X6,f,sigma_noise_square );
    W(:,5)=weight_vector6;
    [prediction,err] = validation( X_,n_,f_,weight_vector,W,4,sigma_noise_square);
    validation_error(6)=validation_error(6)+err;
    %----------------------------------------------
    validation_index = validation_index + 1;
end
validation_error=validation_error./K
plot([1,2,3,4,5,6],validation_error,'r-*');
title('error vs number of layer : 10-fold cross validation')
xlabel('number of layers') % x-axis label
ylabel('mean error') % y-axis label

