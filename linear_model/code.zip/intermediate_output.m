function output = intermediate_output( X,weight_vector,n )
for i=1:n
    tmp(i) = X(:,i)'*weight_vector;
end
output = tmp;
end

